<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="simple" tilewidth="32" tileheight="32" tilecount="72" columns="12">
 <image source="../../../Images/Tilesets/simple/set.png" width="384" height="192"/>
 <terraintypes>
  <terrain name="StoneOnDirt" tile="13"/>
  <terrain name="GrassOnDirt" tile="28"/>
 </terraintypes>
 <tile id="0" terrain=",,,0"/>
 <tile id="1" terrain=",,0,0"/>
 <tile id="2" terrain=",,0,"/>
 <tile id="3" terrain=",,,1"/>
 <tile id="4" terrain=",,1,1"/>
 <tile id="5" terrain=",,1,"/>
 <tile id="6" terrain="0,0,0,"/>
 <tile id="7" terrain="0,0,,"/>
 <tile id="8" terrain="0,0,,0"/>
 <tile id="9" terrain="1,1,1,"/>
 <tile id="10" terrain="1,1,,"/>
 <tile id="11" terrain="1,1,,1"/>
 <tile id="12" terrain=",0,,0"/>
 <tile id="13" terrain="0,0,0,0"/>
 <tile id="14" terrain="0,,0,"/>
 <tile id="15" terrain=",1,,1"/>
 <tile id="16" terrain="1,1,1,1"/>
 <tile id="17" terrain="1,,1,"/>
 <tile id="18" terrain="0,,0,"/>
 <tile id="20" terrain=",0,,0"/>
 <tile id="21" terrain="1,,1,"/>
 <tile id="23" terrain=",1,,1"/>
 <tile id="24" terrain=",0,,"/>
 <tile id="25" terrain="0,0,,"/>
 <tile id="26" terrain="0,,,"/>
 <tile id="27" terrain=",1,,"/>
 <tile id="28" terrain="1,1,,"/>
 <tile id="29" terrain="1,,,"/>
 <tile id="30" terrain="0,,0,0"/>
 <tile id="31" terrain=",,0,0"/>
 <tile id="32" terrain=",0,0,0"/>
 <tile id="33" terrain="1,,1,1"/>
 <tile id="34" terrain=",,1,1"/>
 <tile id="35" terrain=",1,1,1"/>
</tileset>
