<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="desolate_desert" tilewidth="32" tileheight="32" tilecount="312" columns="12">
 <image source="../../../Images/Tilesets/desolate_desert/set.png" width="384" height="832"/>
</tileset>
