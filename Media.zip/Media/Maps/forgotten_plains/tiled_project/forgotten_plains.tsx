<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="forgotten_plains" tilewidth="32" tileheight="32" tilecount="352" columns="16">
 <image source="../../../Images/Tilesets/forgotten_plains/forgotten_plains.png" width="512" height="704"/>
</tileset>
